package com.example.asd;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private TextView tvCoordinates, tvRefreshed;
    private FrameLayout gameContainer;
    private GameView gameView;
    private LocationManager locationManager;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private DatabaseHelper helper; // Added to handle SQLite operations

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //数据库操作部分~~~
        helper = new DatabaseHelper(this); // Initialize DatabaseHelper

        tvCoordinates = findViewById(R.id.tv_coordinates);
        tvRefreshed = findViewById(R.id.tv_refreshed);
        gameContainer = findViewById(R.id.game_container);

        gameView = new GameView(this);
        gameContainer.addView(gameView);

        Button btnUp = findViewById(R.id.btn_up);
        Button btnDown = findViewById(R.id.btn_down);
        Button btnLeft = findViewById(R.id.btn_left);
        Button btnRight = findViewById(R.id.btn_right);

        btnUp.setOnClickListener(v -> gameView.move(0, -50));
        btnDown.setOnClickListener(v -> gameView.move(0, 50));
        btnLeft.setOnClickListener(v -> gameView.move(-50, 0));
        btnRight.setOnClickListener(v -> gameView.move(50, 0));

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            startLocationUpdates();
        }

        // 定时更新刷新状态
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> tvRefreshed.setText("Refreshed"));
            }
        }, 0, 1000);
    }

    private void startLocationUpdates() {
        if (locationManager != null) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, locationListener);
        }
    }

    public void insert(Location location)
    {
        SQLiteDatabase write = helper.getWritableDatabase();
        String sql = "INSERT INTO Location (longitude, latitude, timestamp) VALUES (?, ?, CURRENT_TIMESTAMP)";
        write.execSQL(sql, new Object[]{location.getLongitude(), location.getLatitude()});
        write.close();
    }

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            tvCoordinates.setText("Coordinates: " + location.getLatitude() + ", " + location.getLongitude());

            insert(location); // Modified to use the new insert method
            SQLiteDatabase read = helper.getReadableDatabase();
            if(read.isOpen()){
                Cursor cursor = read.rawQuery("SELECT * FROM Location", null);
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(0);
                    double Latitude = cursor.getDouble(1);
                    double Longitude = cursor.getDouble(2);
                    System.out.println(id + " Latitude: " + Latitude + " Longitude: " + Longitude);
                }
                cursor.close();
            }
            read.close();


        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startLocationUpdates();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (locationManager != null) {
            locationManager.removeUpdates(locationListener);
        }
    }

    private class GameView extends View {

        private Paint paint = new Paint();
        private int x = 100, y = 100;

        public GameView(Context context) {
            super(context);
            paint.setColor(0xFF0000FF); // Blue color
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawColor(0xFFFFFFFF); // White background
            canvas.drawRect(x, y, x + 50, y + 50, paint);
        }

        public void move(int dx, int dy) {
            x += dx;
            y += dy;
            // 使用取模运算确保色块不会离开屏幕
            if (x < 0) x += getWidth();
            if (y < 0) y += getHeight();
            if (x >= getWidth()) x -= getWidth();
            if (y >= getHeight()) y -= getHeight();
            invalidate(); // 重绘视图
        }
    }
}